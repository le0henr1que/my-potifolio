---
name: "❓Dúvida"
about: Esclarecimento de dúvidas
title: 'Etapa X, nome do vídeo: X'
labels: "❓ dúvida"
assignees: ''

---

<!--
ATENÇÃO: Leia antes de postar sua dúvida.
-----------------------------------------------
Primeiro, certifique-se de que você inseriu no título nome da etapa e nome do vídeo corretos. Isso facilita para mim na hora de lhe responder.

Se você precisar adicionar trechos de código, coloque-os entre 3 crases, assim:

```js
const myFunc = () => {

}
```

Colocando 3 crases antes, 3 crases depois, o código aparecerá corretamente
formatado. O "js" ali em cima é para que o código seja corretamente colorizado
com base na linguagem JS.

Antes de publicar a issue, lembre-se de clicar na aba "Preview", para visualizar se a formatação está correta.

Quanto mais específico você for, mais fácil será ajudá-lo(a) =)
-->

<!-- ESCREVA SUA DÚVIDA APÓS ESSA LINHA -->



<!-- Não apague daqui para baixo! -->
@Roger-Melo
