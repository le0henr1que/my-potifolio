---
name: "\U0001F4C4Resumo"
about: Issues relacionadas aos resumos das aulas
title: Resumo da Aula Xxxxxxxxx da etapa XX
labels: "\U0001F4C4resumo"
assignees: ''

---

<!--
Antes de publicar a issue, lembre-se de clicar na aba "Preview", para visualizar se a formatação está correta =)
-->

<!-- Escreva/insira as imagens após essa linha -->

