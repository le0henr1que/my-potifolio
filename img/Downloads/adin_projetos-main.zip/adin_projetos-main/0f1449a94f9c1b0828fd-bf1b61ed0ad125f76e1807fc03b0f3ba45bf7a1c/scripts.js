//Twitter
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');

//Facebook
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
     	js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
      fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));

$(document).ready(function(){

//Smooth Scrolling
	$('body').scrollspy({target: ".navbar", offset: 50});   
      $("#myNavbar a").on('click', function(event) {
        event.preventDefault();
        var hash = this.hash;
        $('html, body').animate({
         		scrollTop: $(hash).offset().top
        }, 800, function(){
      window.location.hash = hash;
    });
  });

//Setller
$.stellar();

//Tooltip
	$(function(){
  	$('#item1').tooltip();
	});

	$(function(){
  	$('#item2').tooltip();
	});

	$(function(){
  	$('#item3').tooltip();
	});

	$(function(){
    $('[data-toggle="tooltip"]').tooltip();
  });

// Outlining the Textbox area
$('#message').css("border", "2px solid red");

//Event Handler for Submit Button
$('#submit').on("click", function(){

	var name = $("#name").val();
	var email = $("#email").val();
	var phone = $("#phone").val();
	var message = $("#message").val();
	
	if (email === ""){
		$("#email").css("border", "3px solid #8000FF")
		}	else {
				$("#visible-email").html(message);
				$("#email").hide();
				$("#submit").hide();	
		};

	if (phone === ""){
		$("#phone").css("border", "3px solid #FE2EF7")
		}	else {
				$("#visible-phone").html(message);
				$("#phone").hide();
				$("#submit").hide();	
		};

	if (message === ""){
		$("#message").css("border", "3px solid #40FF00")
		}	else {
				$("#visible-message").html(message);
				$("#message").hide();
				$("#submit").hide();	
		};

	return false;
});

$("#message").on("keyup", function(){
	console.log("keyup happened");
	var charCount = $("#message").val().length;
	console.log(charCount);
	$("#charCount").html(charCount);
	if(charCount > 50){
		$("#charCount").css("color", "#FE2EC8");
		} else {
			$("#charCount").css("color", "#58FAF4");		
	};
});	

//Work section
for (var i = 0; i < works.length; ++i){
	$("#work").append("\
		<div class='col-lg-3 col-md-3 col-xs-6'>\
          <img class='img-responsive' src='" + works[i] + "'>\
        </div>\
  ");
var images = $("#work img");
	if (i%2 === 0) {
		$(images[i]).css("border", "2px solid Magenta");
	} else {
		$(images[i]).css("border", "2px solid Lime");	
};

};


});