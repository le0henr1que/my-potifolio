function CPF(){
    document.getElementById("CPF").style.display = "block"
    document.getElementById("Cupom").style.display = "none"
    document.getElementById("Cartao").style.display = "none"
    document.getElementById("SKU").style.display = "none"
}

function CUPOM(){
    document.getElementById("CPF").style.display = "none"
    document.getElementById("Cupom").style.display = "block"
    document.getElementById("Cartao").style.display = "none"
    document.getElementById("SKU").style.display = "none"
}

function CARTAO(){
    document.getElementById("CPF").style.display = "none"
    document.getElementById("Cupom").style.display = "none"
    document.getElementById("Cartao").style.display = "block"
    document.getElementById("SKU").style.display = "none"
}

function SKU(){
    document.getElementById("CPF").style.display = "none"
    document.getElementById("Cupom").style.display = "none"
    document.getElementById("Cartao").style.display = "none"
    document.getElementById("SKU").style.display = "block"
}

function buscaCPF() {
    // Limpa as respostas a cada nova consulta - Removendo todos os nós filhos de um elemento
    var clearConsult = document.getElementById('span-resposta')
    while (clearConsult.firstChild) {
        clearConsult.removeChild(clearConsult.firstChild);
    }

    var objCPF
    let valorCPF = document.getElementById("fCPF").value
    let URLBase = "https://apicev.azurewebsites.net/RightNowApi/consultaDadosCRM/cpf/"
    let xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            //document.getElementById("resposta").innerHTML = this.responseText
            //document.getElementById("resposta").style.display = "block"
            objCPF = this.responseText
            objCPF = JSON.parse(objCPF) //analisa uma string JSON, construindo o valor ou um objeto JavaScript descrito pela string
            console.log(objCPF)
            
            //Pega os dados do cliente (nome, cpf, etc.)
            var dadosCliente = objCPF.cliente
            console.log(dadosCliente)
            
            //Mostrar dados do cliente na tela
            var paiDaDivCliente = document.getElementById('resposta')
            var chamado = document.createElement('div') 
            var divDadosCliente = document.createElement('div')
            chamado.setAttribute('class', 'chamado')
            divDadosCliente.setAttribute('id', 'dados-cliente')
            paiDaDivCliente.prepend(divDadosCliente)
            for(var [key, value] of Object.entries(dadosCliente)){
                var dataWrapper = document.createElement('div')
                var campo = document.createElement('label')
                var campoContent = document.createTextNode(key)
                if(key == 'numCnpjCpf'){
                    campoContent = document.createTextNode("CPF")
                }else if(key == 'nomRazaoSocial'){
                    campoContent = document.createTextNode("Nome")
                }else if(key == 'numTelefone'){
                    campoContent = document.createTextNode("Nº Telefone")
                }else if(key == 'nomEndereco'){
                    campoContent = document.createTextNode("Endereço")
                }else if(key == 'nomBairro'){
                    campoContent = document.createTextNode("Bairro")
                }else if(key == 'nomMunicipio'){
                    campoContent = document.createTextNode("Município")
                }else if(key == 'nomEstado'){
                    campoContent = document.createTextNode("Estado")
                }else if(key == 'txtEmail'){
                    campoContent = document.createTextNode("E-mail")
                }else if(key == 'codCategoriaClientePDV'){
                    campoContent = document.createTextNode("Categoria Cliente PDV")
                }else if(key == 'clusterClienteOrigem'){
                    campoContent = document.createTextNode("Cluster Cliente Origem")
                }else if(key == 'origem'){
                    campoContent = document.createTextNode("Origem")
                }else if(key == 'datAtualizacao'){
                    campoContent = document.createTextNode("Data de Atualização")
                }
                var valor = document.createElement('div')
                var valorContent = document.createTextNode(value)
                dataWrapper.setAttribute('class', 'data-wrapper')
                campo.setAttribute('class', 'labelTitle')
                valor.setAttribute('class', 'fieldbox')
                dataWrapper.appendChild(campo)
                dataWrapper.appendChild(valor)
                chamado.appendChild(dataWrapper)
                campo.appendChild(campoContent)
                valor.appendChild(valorContent)
                divDadosCliente.appendChild(chamado)
            }

            //Separar dados do cliente de dados telefonicos
            var newLine = document.createElement('br')
            var divider = document.createElement('hr')
            divDadosCliente.appendChild(newLine)
            divDadosCliente.appendChild(divider)
            
            //Percorre o array de objetos, retornando outro array de objetos (o qual contém os dados de Atendimento
            //Telefonico do usuário)
            var dadosAtendimentoTelefonico = objCPF.listaAtendimentoTelefonico.map(element =>{
                return Object.values(element)
            })  
            console.log(dadosAtendimentoTelefonico)

            var elemento_pai = document.getElementById('span-resposta')
            //Percorre o array (listaAtendimentoTelefonico) com os objetos dos usuários para fazer as tratativas
            dadosAtendimentoTelefonico.map(element => {
                var chamado = document.createElement('div')
                for (var property in element){
                    /*Se tal propriedade for a 1a do array, insere um espaço e uma linha após o último nó
                    do elemento span-resposta*/
                    if(property == 0){
                        var lastElement = document.getElementById('span-resposta').lastElementChild
                        $("<br>").insertAfter(lastElement);
                    }
                    var dataWrapper = document.createElement('div')
                    var newLabel = document.createElement('label')
                    var newDiv = document.createElement('div')
                    chamado.setAttribute('class', 'chamado')
                    dataWrapper.setAttribute('class', 'data-wrapper')
                    newLabel.setAttribute('class', 'labelTitle')
                    newDiv.setAttribute('class', 'fieldbox')
                    var labelTitle = document.createTextNode(property)
                    //Verifica qual é a propriedade do objeto para mostrar o nome correto
                    if(property == 0){
                        labelTitle = document.createTextNode("ID da Ligação")
                    }else if(property == 1){
                        labelTitle = document.createTextNode("CPF")
                    }else if(property == 2){
                        labelTitle = document.createTextNode("Data do Atendimento")
                    }else if(property == 3){
                        labelTitle = document.createTextNode("Nº do Telefone")
                    }else if(property == 4){
                        labelTitle = document.createTextNode("Nº da Matrícula do Atendente")
                    }else if(property == 5){
                        labelTitle = document.createTextNode("Nº do Ticket")
                    }else if(property == 6){
                        labelTitle = document.createTextNode("Data de Espera")
                    }
                    var content = document.createTextNode(element[property])
                    newLabel.appendChild(labelTitle)
                    newDiv.appendChild(content);
                    dataWrapper.appendChild(newLabel)
                    dataWrapper.appendChild(newDiv)
                    chamado.appendChild(dataWrapper)
                    elemento_pai.appendChild(chamado)
                  }
            });
            //REFATORAR ESSA PARTE DE BAIXO****
            /*
            objCPF.listaAtendimentoTelefonico.map(element => {
                for (var property in element){
                    if(property == 'numCallId'){
                        var lastElement = document.getElementById('span-resposta').lastElementChild
                        $("<br>").insertAfter(lastElement);
                    }
                    var elemento_pai = document.getElementById('span-resposta')
                    var newLabel = document.createElement('label')
                    var newDiv = document.createElement('div')
                    newLabel.setAttribute('class', 'labelTitle')
                    newDiv.setAttribute('class', 'fieldbox')
                    var labelTitle = document.createTextNode(property)
                    if(property == 'numCallId'){
                        labelTitle = document.createTextNode("ID da Ligação")
                    }else if(property == 'cpf'){
                        labelTitle = document.createTextNode("CPF")
                    }else if(property == 'datHoraAtendimento'){
                        labelTitle = document.createTextNode("Data do Atendimento")
                    }else if(property == 'numTelefone'){
                        labelTitle = document.createTextNode("Número do Telefone")
                    }else if(property == 'numMatriculaAtendente'){
                        labelTitle = document.createTextNode("Número da Matrícula do Atendente")
                    }else if(property == 'numTicket'){
                        labelTitle = document.createTextNode("Número do Ticket")
                    }
                    var content = document.createTextNode(element[property])
                    newLabel.appendChild(labelTitle)
                    newDiv.appendChild(content);
                    elemento_pai.appendChild(newLabel)
                    elemento_pai.appendChild(newDiv)
                    //console.log(property + " = " + element[property]);
                  }
            });*/
            /*
            objCPF.listaAtendimentoTelefonico.map(element => {
                console.log("Meu element", element)
            });*/
            //document.getElementById("resposta").innerHTML = objCPF.listaAtendimentoTelefonico
            document.getElementById("resposta").style.display = "block"
        }
        
    }
    xhttp.open("GET",URLBase+valorCPF,true)
    xhttp.send()
    return objCPF
}

function buscaCupom() {
    let numeroCupom = document.getElementById("fNumCupom").value
    let codFilial = document.getElementById("fCodFilial").value
    let pdv = document.getElementById("fCodPDV").value
    let URLBase1 = "https://apicev.azurewebsites.net/RightNowApi/visualizarCupom/numCupom/"
    let URLBase2 = "/codFilial/"
    let URLBase3 = "/codPDV/"
    let xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("resposta").innerHTML = this.responseText
            document.getElementById("resposta").style.display = "block"
            return JSON.parse(this.responseXML)
        }
    }
    xhttp.open("GET",URLBase1+numeroCupom+URLBase2+codFilial+URLBase3+pdv,true)
    xhttp.send()
}

function buscaCartao() {
    let valorCartao = document.getElementById("fNumCartao").value
    let URLBase = "https://apicev.azurewebsites.net/RightNowApi/consultaCupomPorNumeroCartao/numCartaoCredito/"
    let xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("resposta").innerHTML = this.responseText
            document.getElementById("resposta").style.display = "block"
            return JSON.parse(this.responseXML)
        }
    }
    xhttp.open("GET",URLBase+valorCartao,true)
    xhttp.send()
}

function buscaSKU() {
    let valorSKU = document.getElementById("fSKU").value
    let URLBase = "https://apicev.azurewebsites.net/RightNowApi/consultaEstoque/sku/"
    let xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("resposta").innerHTML = this.responseText
            document.getElementById("resposta").style.display = "block"
            return JSON.parse(this.responseXML)
        }
    }
    xhttp.open("GET",URLBase+valorSKU,true)
    xhttp.send()
}