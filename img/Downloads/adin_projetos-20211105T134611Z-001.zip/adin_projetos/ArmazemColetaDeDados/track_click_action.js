
/*-------------------------------------esse vai no script prod1--------------------------*/
setTimeout(function(){ 

    let prod1Cli  = document.querySelector("#prod1link > p:nth-child(1)").textContent.trim();

    /*configuration block begin*/
    var config1 = {
        "actionName": "clickck_produto_01",
        "value": 1,
        "attr": prod1Cli
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();

}, 3000); 





    
    
    /*-------------------------------------esse vai na action prod1--------------------------*/
    setTimeout(function(){ 
         
        let prod1Cli  = document.querySelector("#prod1link > p:nth-child(1)").textContent.trim();

      /*configuration block begin*/
      var config = {
        "actionName": "clickck_produto_01",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = prod1Cli
 
         
    actions.set(config.actionName, config.value, config.attr).send();
    
    }, 3000); 
    
    



    
/*-------------------------------------esse vai no script prod2--------------------------*/
setTimeout(function(){ 

    let prod2Cli  = document.querySelector("#prod2link > p:nth-child(1)").textContent.trim();

    /*configuration block begin*/
    var config1 = {
        "actionName": "clickck_produto_02",
        "value": 1,
        "attr": prod2Cli
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();

}, 3000); 





    
    
    /*-------------------------------------esse vai na action prod2--------------------------*/
    setTimeout(function(){ 
         
        let prod2Cli  = document.querySelector("#prod2link > p:nth-child(1)").textContent.trim();

      /*configuration block begin*/
      var config = {
        "actionName": "clickck_produto_02",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = prod2Cli
 
         
    actions.set(config.actionName, config.value, config.attr).send();
    
    }, 3000); 
    
    


    
    
/*-------------------------------------esse vai no script prod3--------------------------*/
setTimeout(function(){ 

    let prod3Cli  = document.querySelector("#prod3link > p:nth-child(1)").textContent.trim();

    /*configuration block begin*/
    var config1 = {
        "actionName": "clickck_produto_03",
        "value": 1,
        "attr": prod3Cli
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();

}, 3000); 





    
    
    /*-------------------------------------esse vai na action prod3--------------------------*/
    setTimeout(function(){ 
         
        let prod3Cli  = document.querySelector("#prod3link > p:nth-child(1)").textContent.trim();

      /*configuration block begin*/
      var config = {
        "actionName": "clickck_produto_03",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = prod3Cli
 
         
    actions.set(config.actionName, config.value, config.attr).send();
    
    }, 3000); 
    
    
    
    
/*-------------------------------------esse vai no script prod4--------------------------*/
setTimeout(function(){ 

    let prod4Cli  = document.querySelector("#prod4link > p:nth-child(1)").textContent.trim();

    /*configuration block begin*/
    var config1 = {
        "actionName": "clickck_produto_04",
        "value": 1,
        "attr": prod4Cli
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();

}, 3000); 





    
    
    /*-------------------------------------esse vai na action prod4--------------------------*/
    setTimeout(function(){ 
         
        let prod4Cli  = document.querySelector("#prod4link > p:nth-child(1)").textContent.trim();

      /*configuration block begin*/
      var config = {
        "actionName": "clickck_produto_04",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = prod4Cli
 
         
    actions.set(config.actionName, config.value, config.attr).send();
    
    }, 3000); 
    
    
    