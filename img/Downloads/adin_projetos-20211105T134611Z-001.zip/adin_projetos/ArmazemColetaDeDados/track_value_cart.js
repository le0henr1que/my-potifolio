/*-------------------------------------esse vai no script--------------------------*/
setTimeout(function(){ 
     
    let con = document.querySelector("#CC-orderSummary-orderTotal > span.ordersumprice.pull-right").textContent
    let numsStr = con.replace(/[^0-9,]*/g, '').replace(',', '.');
    let numStr2 = parseFloat(numsStr)
    var precoFormatado22 = numStr2.toLocaleString('pt-br', {minimumFractionDigits: 2})
    
    console.log(precoFormatado22)
    
    /*configuration block begin*/
    var config1 = {
        "actionName": "Custom Action 2",
        "value": 1,
        "attr": precoFormatado22
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();
         
             }, 3000); 

/*-------------------------------------esse vai na action--------------------------*/

setTimeout(function(){ 
     
    let con = document.querySelector("#CC-orderSummary-orderTotal > span.ordersumprice.pull-right").textContent
    let numsStr = con.replace(/[^0-9,]*/g, '').replace(',', '.');
    let numStr2 = parseFloat(numsStr)
    var precoFormatado22 = numStr2.toLocaleString('pt-br', {minimumFractionDigits: 2})
    
    console.log(precoFormatado22)
    
    /*configuration block begin*/
    var config = {
        "actionName": "Custom Action 2",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = precoFormatado22
         
    actions.set(config.actionName, config.value, config.attr).send();
         
               }, 4000); 


/* o ActionNmae tem que ser iguais em todos os dois script e no nome da açao*/







/*-------------------quantidade cart-(action)------------------------*/

setTimeout(function(){ 

let numini = localStorage.getItem("shoppingCart").split(",")[0]
let nummei  = numini.replace(/[^0-9$.,]/g, '')
let numfim = parseInt(nummei)
console.log(numfim)
/*configuration block begin*/
    var config = {
        "actionName": "Quantidade Cart",
        "value": 1,
        "attr": "Quantidade Cart"
    };
    /*configuration block end*/
    config[0].value = numfim
         
    actions.set(config.actionName, config.value, config.attr).send();
}, 4000); 

/*-------------------quantidade cart-(script)------------------------*/

setTimeout(function(){ 

    let numini = localStorage.getItem("shoppingCart").split(",")[0]
    let nummei  = numini.replace(/[^0-9$.,]/g, '')
    let numfim = parseInt(nummei)
    console.log(numfim)
    /*configuration block begin*/
        var config = {
            "actionName": "Quantidade Cart",
            "value": numfim,
            "attr": "Quantidade Cart"
        };
        /*configuration block end*/
        //config[0].value = numfim
             
        actions.set(config.actionName, config.value, config.attr).send();
    }, 4000); 