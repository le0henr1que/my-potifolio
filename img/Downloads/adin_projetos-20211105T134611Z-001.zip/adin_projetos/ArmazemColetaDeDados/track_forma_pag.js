
/*-------------------------------------esse vai no script--------------------------*/
setTimeout(function(){ 

    let tip_pag = document.getElementsByClassName("active")[0].textContent

    /*configuration block begin*/
    var config1 = {
        "actionName": tip_pag,
        "value": 1,
        "attr": tip_pag
    };
    /*configuration block end*/
    //config1[0].attr = precoFormatado22
    
    actions.set(config1.actionName, config1.value, config1.attr).send();

}, 3000); 





    
    
    /*-------------------------------------esse vai na action --------------------------*/
    setTimeout(function(){ 
         
    let tip_pag = document.getElementsByClassName("active")[0].textContent

      /*configuration block begin*/
      var config = {
        "actionName": "Custom Action 2",
        "value": 1,
        "attr": ""
    };
    /*configuration block end*/
    config[0].attr = tip_pag
    config[0].actionName = tip_pag
         
    actions.set(config.actionName, config.value, config.attr).send();
    
    }, 3000); 
    
    