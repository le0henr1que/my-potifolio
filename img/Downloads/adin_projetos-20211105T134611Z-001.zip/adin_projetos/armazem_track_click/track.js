
let produto_01 = document.querySelector("#prod1link > p").textContent
let produto_02 = document.querySelector("#prod2link > p").textContent
let produto_03 = document.querySelector("#prod3link > p").textContent
let produto_04 = document.querySelector("#prod4link > p").textContent

/*configuration block begin*/
var config = {
	"actionName": "Click Action 21",
	"selectorsDefault": {},
	"selectorsAfter": {
		"element1": {
			"produtos_nov_p_voce": {
				"#prod1link > p": {
					"value": 1,
					"attr": produto_01
				},
				"#prod2link > p": {
					"value": 1,
					"attr": produto_02
				},
				"#prod3link > p": {
					"value": 1,
					"attr": produto_03
				},
				"#prod4link > p": {
					"value": 1,
					"attr": produto_04
				}
			}
		}
	},
	"urls": null
};
/*configuration block end*/

var domReadyDeferred = Deferred();
events.domReady(function(){
    domReadyDeferred.resolve();
});

var isUrlMatched = function(url, includedUrls, excludedUrls) {
    var isIncluded = isMasksMatch(url, includedUrls);
    var isExcluded = isMasksMatch(url, excludedUrls);
    return isIncluded && !isExcluded;
};

var isMasksMatch = function(url, masks) {
    if (!url) {
        return false;
    }
    url = url.toLowerCase();

    for (var i = 0; i < masks.length; i++) {
        var mask = masks[i].toLowerCase();
        if (isMaskMatch(url, window.deproxy ? window.deproxy({
            href: mask
        }).href : mask)) {
            return true;
        }
    }
    return false;
};

var isMaskMatch = function(url, originalMask) {
    var mask = '^';
    var pos = 0;
    while (originalMask.length > pos) {
        var char = originalMask[pos];
        if (char == '*') {
            mask = mask + '.*';
            pos = pos + 1;
        } else if (char == '(') {
            var posClosing = originalMask.indexOf(')', pos + 1);
            var posNextOpening = originalMask.indexOf('(', pos + 1);
            if (posClosing > pos && (posNextOpening < 0 || posClosing < posNextOpening)) {
                mask = mask + '.*';
                pos = posClosing + 1;
            } else {
                return false;
            }
        } else {
            mask = mask + char;
            pos = pos + 1;
        }
    }
    mask = mask + '$';
    mask = mask.replace('?', "\\?");
    var r = new RegExp(mask);
    return r.test(url);
};

var waitForElement = function(elementSelector, timeoutValue){
    var elementDeferred = Deferred();
    var timeout = false;
    domReadyDeferred.promise().then(function(){
        setTimeout(function () {
            timeout = true;
        }, timeoutValue);
    });

    renderer.when(function(){
        return timeout || dom.find(elementSelector).length;
    })
        .done(function(){ elementDeferred.resolve(); })
        .fail(function(){ elementDeferred.reject(); });

    return elementDeferred.promise();
};

var getActionElement = function(selector, data) {
    var deferred = Deferred();

    if (selector) {
        waitForElement(selector, 2000)
            .done(function(){
                var elements = dom.find(selector);
                if (elements.length) {
                    var elementData = {
                        selector: selector,
                        data: data
                    };
                    deferred.resolveWith(this, [elements[0], elementData]);
                } else {
                    deferred.reject();
                }
            })
            .fail(function(){
                deferred.reject();
            });
    } else {
        deferred.reject();
    }

    return deferred.promise();
};

var getCurrentUrl = function() {
    return window.deproxy
        ? window.deproxy(window.location).href
        : window.location.href;
};

var isActionRequired = function() {
    return !config.urls
        ? true
        : !!isUrlMatched(
            getCurrentUrl(),
            config.urls.includedUrls,
            config.urls.excludedUrls);
};

var trackClicksAction = function(selectors) {
    if (isActionRequired()) {
        for(var selector in selectors){
            getActionElement(selector, selectors[selector]).done(function (element, elementData){
                if(element && (!element.attachedActions || !element.attachedActions[config.actionName])){
                    actions.trackClicks(elementData.selector, {name: config.actionName, value:elementData.data.value, attribute:elementData.data.attr});
                    if (!element.attachedActions) { element.attachedActions = {}; }
                    element.attachedActions[config.actionName] = true;
                }
            });
        }
    }
};

trackClicksAction(config.selectorsDefault);

campaign.events.on('urlChange', function(){ trackClicksAction(config.selectorsDefault); });

campaign.events.variantJsExecuted(function(elementName, variantName){
    var selectorsAfter = (config.selectorsAfter[elementName] || {})[variantName.toLowerCase()] || {};
    trackClicksAction(selectorsAfter);
});
