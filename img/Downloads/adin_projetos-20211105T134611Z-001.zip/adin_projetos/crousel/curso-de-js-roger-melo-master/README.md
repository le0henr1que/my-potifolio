![](assets/banner-cjrm-readme.jpg)

<h2 align="center">
  Curso de JavaScript Roger Melo
</h2>

### Depoimentos de alunos

- [De estagiário à Front-end Developer em um mês e meio](https://youtu.be/IvG47ce4kz0)
- [Contratado como Full-stack Developer pela Kabum com apenas 4 meses de estudos](https://youtu.be/8nwGTNKa6gM)
- [Conquistou uma vaga com apenas 65% do curso concluído](https://drive.google.com/file/d/1e1M018usvoQg0r4GmBL6t4xf-L6wSp1c/view?usp=sharing)
- [Conquistou uma vaga como Dev. Front-end com apenas 61% do curso concluído](https://drive.google.com/file/d/149B7RoLwNoKveTpCa1_tGa3GEs1VMBi2/view?usp=sharing)
- [Contratado por uma multinacional como Full-stack Developer](https://drive.google.com/file/d/1WQwzElmTwlZgvhLz8zf1pi-ZStjGb2Fh/view?usp=sharing)
- [Mesmo com as dificuldades, ele se consolidou como Front-end Developer](https://youtu.be/eBAav-o49vo)
- [O freelancer que tinha dificuldades com JavaScript e hoje constrói aplicações do zero](https://youtu.be/ohS6JsCmYys)
- ["Não sou de fazer vídeo pra curso. Mas esse eu tive que fazer"](https://youtu.be/tJ1hZGb0aOY)
- [Ele começou do zero e já entende o que frameworks fazem por baixo dos panos](https://youtu.be/oaANN2qb8dw)

### Tem alguma dúvida?

Para falar comigo, envie um e-mail para oi@rogermelo.com.br
