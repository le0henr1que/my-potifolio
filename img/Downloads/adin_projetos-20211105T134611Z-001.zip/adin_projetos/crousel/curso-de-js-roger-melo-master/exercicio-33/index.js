const book = {
  name: 'Rápido e devagar',
  author: 'Daniel Kahneman',
  pages: 608,
  releaseYear: 2012,
  publisher: 'Objetiva',
  price: 44.90
}
