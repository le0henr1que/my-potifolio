const version = '/api/v1'

module.exports = (app, endpoint, method, callback) => {
    app.route(version+endpoint)[method](callback)
}