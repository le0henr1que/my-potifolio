const mongoose = require('mongoose')
const clients = require('../config/databases.json')

mongoose.set('useNewUrlParser', true)
mongoose.set('useFindAndModify', false)
mongoose.set('useCreateIndex', true)

let connections = {}

exports.createConnections = async () => {
    for (let i = 0; i < clients.length; i++) {
      let e = clients[i]
      let conn = await mongoose.createConnection(`mongodb://${e.location}:${e.port}/${e.database}`, {useUnifiedTopology: true})
      console.log(`[SUCCESS] Mongo connect ${e.name} at the port:27017`)
      connections[e.name] = conn
    }
}

exports.getConnections = async () => {
  return connections
}