const kafka       = require('kafka-node');
const config      = require('config');
const Producer    = kafka.Producer;

module.exports = async (payload, topic, partition) => {
    return new Promise((resolve, reject) => {

        const client     = new kafka.KafkaClient({
            kafkakHost: config.get('kafkaHost')
        });

        const producer = new Producer(client);

        producer.on('ready', () => {
            producer.send([{
                topic,
                messages: JSON.stringify(payload),
                partition,
            }], (err, data) => {
                if(err) reject(err)
                if(data) resolve()
            })
        });

        producer.on('error', err => {
            if(err) reject(err)
        });
        
    });
}