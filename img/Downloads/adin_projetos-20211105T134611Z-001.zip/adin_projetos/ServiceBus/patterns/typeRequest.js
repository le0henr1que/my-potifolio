module.exports = async (req, res) => {
    if(await res){ //using routes
        return [req.body || {}, true]
    }else{ //using kafka
        return [req || {}, false]
    }
}