const kafka = require('kafka-node');
const config = require('config');
const Consumer = kafka.Consumer;

module.exports = async (topic, partition, callback) => {
    const client = new kafka.KafkaClient({
        kafkakHost: config.get('kafkaHost')
    });
    
    const consumer = new Consumer(client, [
        {
            topic,
            partition
        }
    ], {
        autoCommit: true
    });
    
    consumer.on('message', message => {           
        callback(JSON.parse(message.value));
    });
    
    consumer.on('error', err => {            
        console.log(err);
    });
}
