const services = require('../config/services.json')

const { createConnections } = require('../database/mongoConnect')

module.exports = async (app) => {

    // connect to databases
    await createConnections()

    // start workflows
    await initWorkflows(app)
}

async function initWorkflows(app){
    for (let i = 0; i < services.length; i++) {
        const e = services[i]
        
        await initEssentials(e.essentials)

        await initRoutes(app, e.routes)

        await initConsumers(e.consumers)
    }
}

async function initEssentials(essentials){
    for (let i = 0; i < essentials.length; i++) {
        let [path, func] = essentials[i].split(':')
        await func == 'default' ? require(path)() : require(path)[func]()
    }
}

async function initRoutes(app, routes){
    for (let i = 0; i < routes.length; i++) {
        const e = routes[i]
        let [path, func] = e.callback.split(':')
        require('../routes/createRoute')(app, e.endpoint, e.method, await func == 'default' ? require(path) : require(path)[func])
    }
}

async function initConsumers(consumers){
    for (let i = 0; i < consumers.length; i++) {
        let e = consumers[i]
        let [path, func] = e.callback.split(':')
        require('../patterns/consumer')(e.topic, e.partition,await func == 'default' ? require(path) : require(path)[func])
    }
}