const mongoose = require('mongoose')
const { getConnections } = require('../../../../database/mongoConnect')

exports.createModel = async clientName => {
    let conn = await getConnections()
    conn = conn[clientName]
    let schema = new mongoose.Schema({
        clientReference: {type: String},
        operationId: {type: String},
        hash_key: {type: String},
        riid: {type: String},
        created_at: {type: Date},
    }, {
        versionKey: false
    })
    return conn.model('responsys_riids', schema, 'responsys_riids')
}