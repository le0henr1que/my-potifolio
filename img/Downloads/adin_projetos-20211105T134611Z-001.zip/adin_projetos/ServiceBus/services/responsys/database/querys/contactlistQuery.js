const { createModel } = require('../schemas/contactlistSchema')

exports.getContactlistRIID = async (clientName, clientReference, hash_key) => {
    let model = await createModel(clientName)
    return await model.findOne({$and: [{clientReference}, {hash_key}]}).exec()
}

exports.removeContactlist = async (clientName, _id) => {
    return new Promise(async resolve => {
        let model = await createModel(clientName)
        model.deleteOne({_id: _id}, err => {
            if(err) console.log('[ERROR] removeContactlist --> ' + err) //debug

            resolve()
        })
    })
}

exports.createContactlistRecord = async (clientName, payload) => {
    return new Promise(async resolve => {
        let model = await createModel(clientName)
        let nr = new model(payload)
        nr.save(err => {
            if(err) console.log(err) //debug

            resolve()
        })
    })
}