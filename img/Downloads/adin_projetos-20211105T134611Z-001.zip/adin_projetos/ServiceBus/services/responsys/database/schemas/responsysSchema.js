const mongoose = require('mongoose')
const { getConnections } = require('../../../../database/mongoConnect')

exports.createModel = async clientName => {
    let conn = await getConnections()
    conn = conn[clientName]
    let schema = new mongoose.Schema({
        name: {type: String},
        _idClient: {type: String},
        access: {type: Object},
        contact_list: {type: Object},
        suplemental: {type: Object},
        pet: {type: Object},
        trigger: {type: Object}
    }, {
        versionKey: false
    })
    return conn.model('responsys_clients', schema, 'responsys_clients')
}