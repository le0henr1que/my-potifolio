const axios = require('axios')

module.exports = async access => {
    return new Promise((resolve, reject) => {
        let formData = new URLSearchParams()
        formData.append('user_name', access.username)
        formData.append('password', access.password)
        formData.append('auth_type', 'password')
        axios.post(access.url_login, formData.toString(), {headers: {'Content-Type': 'application/x-www-form-urlencoded'}})
        .then(async r => {
            access.authToken = r.data.authToken
            access.expiresIn = await calculateExpires(r.data.issuedAt)
            access.endPoint = r.data.endPoint
            resolve()
        }, err => {
            reject(`[ERROR] in getToken for client ${access.username} --> ${err}`)
        })
    })
}

async function calculateExpires(time){
    let date = new Date(new Date().setTime(time))
    date.setHours(date.getHours()+1)
    date.setMinutes(date.getMinutes()+30)
    return date
}