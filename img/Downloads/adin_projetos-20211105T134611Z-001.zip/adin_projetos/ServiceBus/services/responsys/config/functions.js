const limit = 180

exports.sliceRecords = (records) => {
    return new Promise(resolve => {
        if(records > limit){
            resolve([records])
        }else{
            let div = Number((records.length / limit).toFixed(5))
            let count = 0
            let list = []
            for (let i = 0; i < div; i++) {
                list.push(records.slice(count, (count+limit)-1))
                count += limit
                if(i >= div-1){
                    resolve(list)
                }
            }
        }
    })
}