const { createContactlistRecord } = require('../database/querys/contactlistQuery')

module.exports = async (data, {operationId, clientReference, hash_key}) => {
    if(data.records){
        for (let i = 0; i < data.records.length; i++) {
            let record = data.records[i][0]
            if(record.indexOf('MERGEFAILED') < 0){
                await createContactlistRecord('caabus', {
                    clientReference: clientReference,
                    operationId: operationId,
                    hash_key: hash_key,
                    riid: record,
                    created_at: new Date()
                })
            }else{
                console.log('[INFO] saveRIID to contactlist failed, MERGEFAILED operation')
            }
        }
    }
}