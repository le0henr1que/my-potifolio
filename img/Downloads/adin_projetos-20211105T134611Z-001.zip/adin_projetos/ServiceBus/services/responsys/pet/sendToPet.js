const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { sliceRecords} = require('../config/functions')
const { getResponsysAccess } = require('../database/querys/responsysQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let access = await getResponsysAccess('caabus', payload.clientReference, 'access pet')
        if(access){
            if(access.pet[payload.operationName]){
                let result = await initProcess(await sliceRecords(payload.records), access, payload).catch(err => {
                    console.log('[ERRO] initProcess to pet responsys --> ' + JSON.stringify(err, null, 2))
                })
                if(result){
                    if(isRoute) res.status(200).send({records: result})
                    return result
                }else{
                    if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
                }
            }else{
                if(isRoute) res.status(403).send({error: true, message: 'operation not allowed'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }    
}

async function validateFields(payload){
    if(await payload.clientReference && payload.records && payload.operationId && payload.operationName && payload.matchColumn)
        if(await payload.clientReference != '' && Array.isArray(payload.records) && payload.operationId != '' && payload.operationName != '' && payload.matchColumn != '')
            if(await payload.records.length > 0)
                return true
    
    return false
}

async function initProcess(listToSend, confs, payload){
    return new Promise(async resolve => {
        let dataToReturn = []
        for (let i = 0; i < listToSend.length; i++) {
            let e = listToSend[i]
            let fieldNames = Object.getOwnPropertyNames(e[0])
            let data = await sendData(fieldNames, e, confs, payload).catch(err => {
                console.log('[ERRO] sendData to pet responsys --> ' + err)
                dataToReturn.push(err)
            })
            if(data){
                dataToReturn.push(data)
            }
        }
        resolve(dataToReturn)
    })
}

async function sendData(fieldNames, records, {access, pet}, {operationName, matchColumn, matchColumn2}){
    return new Promise(async (resolve, reject) => {
        let data = {
            recordData: {
                fieldNames: fieldNames,
                records: records
            },
            insertOnNoMatch: true,
            updateOnMatch: "REPLACE_ALL",
            matchColumnName1: matchColumn
        }
        if(await matchColumn2) data.matchColumnName2 = matchColumn2
        axios.post(access.endPoint+access.base+pet[operationName], data, {
            headers:{
                'Content-Type': 'application/json',
                'Authorization': access.authToken
            }
        }).then(async r => {
            resolve(r.data.recordData)
        }, error => {
            reject(error.response.data)
        })
    })
}