const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { sliceRecords} = require('../config/functions')
const { getResponsysAccess } = require('../database/querys/responsysQuery')
const { getContactlistRIID, removeContactlist } = require('../database/querys/contactlistQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let access = await getResponsysAccess('caabus', payload.clientReference, 'access trigger')
        if(access){
            if(access.trigger[payload.operationName]){
                let result = await initProcess(await sliceRecords(payload.records), access, payload).catch(err => {
                    console.log('[ERRO] initProcess to trigger responsys --> ' + JSON.stringify(err, null, 2))
                })
                if(result){
                    if(result.length > 0){
                        if(isRoute) res.status(200).send({records: result, has_data: false})
                        return result
                    }else{
                        if(isRoute) res.status(400).send({error: true, message: 'hash_key provided not allowed, please verify the contact_list stage return'})
                    }
                }else{
                    if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
                }
            }else{
                if(isRoute) res.status(400).send({error: true, message: 'operation not allowed'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }    
}

async function validateFields(payload){
    if(await payload.clientReference && payload.records && payload.operationName)
        if(await payload.clientReference != '' && Array.isArray(payload.records) && payload.operationName != '')
            if(await payload.records.length > 0)
                return true
    
    return false
}

async function initProcess(listToSend, confs, payload){
    return new Promise(async resolve => {
        let dataToReturn = []
        for (let i = 0; i < listToSend.length; i++) {
            let e = listToSend[i]
            let riidRecord = await getContactlistRIID('caabus', payload.clientReference, e.operationId)
            if(riidRecord){
                let data = await sendData(riidRecord.riid, confs, payload).catch(err => {
                    console.log('[ERRO] sendData to trigger responsys --> ' + JSON.stringify(err, null, 2))
                    dataToReturn.push(err)
                })
                if(data){
                    await removeContactlist('caabus', riidRecord._id)
                    dataToReturn.push(data)
                }
            }
        }
        resolve(dataToReturn)
    })
}

async function sendData(riid, {access, trigger}, {operationName}){
    return new Promise((resolve, reject) => {
        let data = {
            customEvent: {},
            recipientData: [
                {
                    recipient: {
                        customerId: "CUSTOMER_ID",
                        emailAddress: "EMAIL_ADDRESS_",
                        listName: trigger[operationName].listName,
                        recipientId: riid,
                        mobileNumber: "MOBILE_NUMBER_",
                        emailFormat: "HTML_FORMAT"
                    },
                    optionalData: [{}]
                }
            ]
        }
        axios.post(access.endPoint+access.base+trigger[operationName].base, data, {
            headers:{
                'Content-Type': 'application/json',
                'Authorization': access.authToken
            }
        }).then(async r => {
            resolve(r.data)
        }, error => {
            reject(error.response.data)
        })
    })
}