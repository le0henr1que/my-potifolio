const axios = require('axios')

module.exports = ({url_login, username, password}) => {
    return new Promise((resolve, reject) => {
        axios.get(url_login, {
            auth: {
                username: username,
                password: password
              }
        }).then(async response => {
            if(response.data.token){
                let expires = await calculateExpiresToken()
                resolve({
                    token: response.data.token,
                    expiresIn: expires
                })
            }else reject()
        }, err => {
            console.log('[ERROR] in getToken EiAlerta --> ' + err)
            reject()
        })
    })
}

async function calculateExpiresToken(){
    let now = new Date()
    now.setMinutes(now.getMinutes() + 10)
    return new Date(now)
}