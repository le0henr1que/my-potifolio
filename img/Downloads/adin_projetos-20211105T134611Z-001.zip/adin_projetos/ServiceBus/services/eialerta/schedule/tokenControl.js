const schedule = require('node-schedule')
const { getEiAlertaAccess, saveEiAlertaRecord } = require('../database/query/eialertaQuery')
const getToken = require('../token/getToken')

module.exports = async () => {
    await initRefreshTokens() //refresh at last once after boot
    schedule.scheduleJob('0 */2 * * * *',  async () => {
        await initRefreshTokens()
    })
}

async function initRefreshTokens(){
    let clients = require('../config/clients.json')
    for (let i = 0; i < clients.length; i++) {
        let client = await getEiAlertaAccess(clients[i].database, clients[i]._idClient, 'access')
        if(client)
        if(client.access){
            if(client.access.authToken){
                if(await compareIfExpires(client.access.expiresIn))
                    await updateToken(client)
            }else{
                await updateToken(client)
            }
        }
    }
}

async function updateToken(client){
    getToken(client.access).then(async response => {
        client.access.authToken = response.token
        client.access.expiresIn = response.expiresIn
        client.markModified('access')
        await saveEiAlertaRecord(client)
    }).catch(err => {
        console.log(err) //debug
    })
}

async function compareIfExpires(expires){
    let now = new Date()
    expires = new Date(expires)
    return now.getTime() >= expires.getTime()
}