const axios = require('axios')
const { getEiAlertaAccess } = require('../database/query/eialertaQuery')

module.exports = async (req, res) => {
    if(await validateFields(req.body)){
        initProcess(req.body).then(response => {
            res.status(200).send(response)
        }).catch(err => {
            res.status(400).send({message: "Erro no processamento das informações", payload: err})
        })
    }else{
        res.status(400).send({message: "Campos faltantes"})
    }
}

async function validateFields(body){
    if(body.clientReference && body.operationId && body.payload){
        if(body.payload.destination && body.payload.msgType && body.payload.msgText){
            return true
        }else{
            return false
        }
    }else{
        return false
    }
}

async function initProcess(body){
    return new Promise(async (resolve, reject) => {
        let client = await getEiAlertaAccess('caabus', body.clientReference, 'access sendMessage')
        if(client){
            sendMessage(client.sendMessage, client.access, body.payload).then(response => {
                resolve(response)
            }).catch(err => {
                reject(err)
            })
        }else{
            reject({message: 'Cliente não está habilitado'})
        }
    })  
}

async function sendMessage({endpoint}, {authToken, idApp}, {destination, msgType, msgText}){
    return new Promise(async (resolve, reject) => {
        let payload = {
            type:"set",
            function:"sendWa",
            data:{
                idApp: idApp,
                destination: destination,
                msgType: msgType,
                msgText: msgText
            }
        }
        axios.post(endpoint, payload, {
            headers:{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + authToken
            }
        }).then(response => {
            if(response.status == 200){
                resolve(response.data)
            }else{
                reject({message: 'Retorno inesperado', payload: response.data})
            }
        }, err => {
            reject({message: 'Erro na requisição', payload: err.data})
        })
    })
}