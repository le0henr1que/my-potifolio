const { createModel } = require('../schema/eialertaSchema') 

exports.getEiAlertaAccess = async (clientName, clientReference, select) => {
    let model = await createModel(clientName)
    return await model.findOne({$or: [{name: clientReference}, {_idClient: clientReference}]}).select(select).exec()
}

exports.saveEiAlertaRecord = async payload => {
    return new Promise(resolve => {
        payload.save(err => {
            if(err) console.log(err) //debug

            resolve()
        })
    })
}