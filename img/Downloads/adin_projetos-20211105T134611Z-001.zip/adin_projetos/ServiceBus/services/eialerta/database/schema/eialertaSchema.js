const mongoose = require('mongoose')
const { getConnections } = require('../../../../database/mongoConnect')

exports.createModel = async clientName => {
    let conn = await getConnections()
    conn = conn[clientName]
    let schema = new mongoose.Schema({
        name: {type: String},
        _idClient: {type: String},
        access: {type: Object},
        sendMessage: {type: Object}
    }, {
        versionKey: false
    })
    return conn.model('eialerta_clients', schema, 'eialerta_clients')
}