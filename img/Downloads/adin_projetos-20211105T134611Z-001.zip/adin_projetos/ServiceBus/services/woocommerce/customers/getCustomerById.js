const axios = require('axios')
const { getWooAccess } = require('../database/querys/wooQuery')

module.exports = async (clientReference, customerId) => {
    let access = await getWooAccess('caabus',  clientReference, 'access endpoints')
    let customer = await getData(access, customerId)
    return customer
}

async function getData({access, endpoints}, customerId){
    return new Promise(resolve => {
        axios.get(endpoints.customer.replace('{customerId}', customerId), {
            auth: {
                username: access.customer_key,
                password: access.customer_secret
            }
        }).then(response => {
            resolve(response.data)
        }, err => {
            console.log(err.response.data)
            resolve()
        })
    })
}