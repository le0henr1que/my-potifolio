const UUID = require('../../../patterns/UUID')
const sendToDataExtensions = require('../../salesforce/data_extensions/sendToDataExtension')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    if(clientReferece){
        let coupon = req.body
        if(await validateFields(coupon)){
            await initOperation(clientReferece, coupon)
        }else{
            console.log('[ERROR] hookCoupon woocommerce operation --> validateFields returns false') //debug
        }
    }else{
        console.log('[ERROR] hookCoupon woocommerce operation --> clientReferece is missing (query on hook)') //debug
    }
    res.status(200).send()
}

async function validateFields(coupon){
    if(coupon)
        if(await coupon.id && coupon.code && coupon.amount)
            return true

    return false
}

async function initOperation(clientReference, coupon){
    let operationId = await UUID()

    // get data
    let data_Coupom = await dataToCoupomDE(coupon)
                        .catch(err => {console.log('[ERROR] dataToCoupomDE --> ' + err)}) //object

    let data_EmailRestrictions = await dataToEmailRes(coupon.id, coupon.email_restrictions, coupon.used_by)
                        .catch(err => {console.log('[ERROR] dataToEmailRes --> ' + err)}) //array

    let [data_CupomHasCategorie, data_Categorie] = await dataToCategorie(coupon.id, coupon.product_categories, coupon.excluded_product_categories)
                        .catch(err => {console.log('[ERROR] dataToCategorie --> ' + err)}) //array //array

    let [data_CupomHasProduct, data_Product] = await dataToProduct(coupon.id, coupon.product_ids, coupon.excluded_product_ids)
                        .catch(err => {console.log('[ERROR] dataToProduct --> ' + err)}) //array //array

    //send data
    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Coupom], operationId: operationId, dataExtension: 'coupon', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_EmailRestrictions, operationId: operationId, dataExtension: 'email_restrictions', method: 'put'}))
    // await sendToDataExtensions({clientReference: clientReference, records: data_CupomHasCategorie, operationId: operationId, dataExtension: 'coupon_has_categorie'})
    // console.log(await sendToDataExtensions({clientReference: clientReference, records: data_CupomHasProduct, operationId: operationId, dataExtension: 'coupon_has_product'}))
}

async function dataToCoupomDE(coupon){
    return {
        cod_cupom: coupon.id,
        code: coupon.code,
        amount: coupon.amount ? Number(Number(coupon.amount).toFixed(2)) : 0,
        date_created: coupon.date_created,
        discount_type: coupon.discount_type,
        description: coupon.description,
        date_expires: coupon.date_expires,
        usage_count: coupon.usage_count,
        individual_use: coupon.individual_use,
        usage_limit: coupon.usage_limit,
        usage_limit_per_user: coupon.usage_limit_per_user,
        free_shipping: coupon.free_shipping,
        minimum_amount:coupon.minimum_amount ? Number(Number(coupon.minimum_amount).toFixed(2)) : 0,
        maximum_amount: coupon.maximum_amount ? Number(Number(coupon.maximum_amount).toFixed(2)) : 0
    }
}

async function dataToEmailRes(idCupon, emails, used){
    let data = []
    for (let i = 0; i < emails.length; i++) {
        data.push({
            cod_email_restriction: idCupon + Number((Math.random() * (1000 - 0) + 1000).toFixed(0)),
            cod_cupom: idCupon,
            email: emails[i]
        })
    }
    return data
}

async function dataToCategorie(idCupon, categories, excluded_categories){
    let has_categories = []
    let categorie = []
    for (let i = 0; i < categories.length; i++) {
        categorie.push(categories[i])
        has_categories.push({
            Cupom_idCupom: idCupon,
            Categoria_idCategoria: categories[i],
            Status_2: true
        })
    }
    for (let i = 0; i < excluded_categories.length; i++) {
        categorie.push(excluded_categories[i])    
        has_categories.push({
            Cupom_idCupom: idCupon,
            Categoria_idCategoria: categories[i],
            Status_2: false
        })    
    }
    return [has_categories, categories]
}

async function dataToProduct(idCupon, products, excluded_products){
    let has_product = []
    let product = []
    for (let i = 0; i < products.length; i++) {
        product.push(products[i])
        has_product.push({
            cod_cupom: idCupon,
            cod_produto: products[i],
            status: true
        })
    }
    for (let i = 0; i < excluded_products.length; i++) {
        product.push(excluded_products[i])    
        has_product.push({
            cod_cupom: idCupon,
            cod_produto: products[i],
            status: false
        })    
    }
    return [has_product, product]
}