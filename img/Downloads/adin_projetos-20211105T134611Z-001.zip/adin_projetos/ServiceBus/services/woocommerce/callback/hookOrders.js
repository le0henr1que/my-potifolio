const UUID = require('../../../patterns/UUID')
const sendToDataExtensions = require('../../salesforce/data_extensions/sendToDataExtension')
const getCustomerById = require('../customers/getCustomerById')
const hookCustomers = require('./hookCustomers')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    if(clientReferece){
        let order = req.body
        if(await validateFields(order)){
            await initOperation(clientReferece, order)
        }else{
            console.log('[ERROR] hookOrder woocommerce operation --> validateFields returns false') //debug
        }
    }else{
        console.log('[ERROR] hookOrder woocommerce operation --> clientReferece is missing (query on hook)') //debug
    }
    res.status(200).send()
}

async function validateFields(order){
    if(order)
        if(await order.id && order.total && order.billing && order.status)
            return true

    return false
}

async function initOperation(clientReference, order){
    let operationId = await UUID()
    
    let data_Order = await dataToOrder(order)
                        .catch(err => {console.log('[ERROR] dataToOrder --> ' + err)}) //object

    let data_Billing = await dataToBilling(order.id, order.billing)
                        .catch(err => {console.log('[ERROR] dataToBilling --> ' + err)}) //object

    let data_Shipping = await dataToShipping(order.id, order.shipping)
                        .catch(err => {console.log('[ERROR] dataToShipping --> ' + err)}) //object

    let data_Itens = await dataToItens(order.id, order.line_items)
                        .catch(err => {console.log('[ERROR] dataToItens --> ' + err)}) //array

    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Order], operationId: operationId, dataExtension: 'orders', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Billing], operationId: operationId, dataExtension: 'billing_order', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Shipping], operationId: operationId, dataExtension: 'shipping_order', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_Itens, operationId: operationId, dataExtension: 'itens_order', method: 'put'}))

    let customer = await getCustomerById(clientReference, order.customer_id)
    if(customer) await hookCustomers({query: {clientReference: clientReference}, body: customer})
}

async function dataToOrder(order){
    return {
        cod_pedido: order.id,
        cod_cliente: order.customer_id,
        parent_id: order.parent_id,
        number: order.number,
        order_key: order.order_key,
        created_via: order.created_via,
        version: order.version,
        status_order: order.status,
        currency: order.currency,
        data_criacao: order.data_created,
        data_alteracao: order.modified,
        discount_total: order.discount_total != '' ? Number(Number(order.discount_total).toFixed(2)) : 0,
        discount_tax: order.discount_tax != '' ? Number(Number(order.discount_tax).toFixed(2)) : 0,
        shipping_total: order.shipping_total != '' ? Number(Number(order.shipping_total).toFixed(2)) : 0,
        shipping_tax: order.shipping_tax != '' ? Number(Number(order.shipping_tax).toFixed(2)) : 0,
        cart_tax: order.cart_tax != '' ? Number(Number(order.cart_tax).toFixed(2)) : 0,
        total: order.total != '' ? Number(Number(order.total).toFixed(2)) : 0,
        total_tax: order.total_tax != '' ? Number(Number(order.total_tax).toFixed(2)) : 0,
        prices_include_tax: order.prices_include_tax,
        customer_ip_address: order.customer_ip_address,
        customer_user_agent: order.customer_user_agent,
        payment_method: order.payment_method,
        payment_method_title: order.payment_method_title,
        transaction_id: order.transaction_id,
        data_pagamento: order.date_paid,
        data_completada: order.date_completed,
        cart_hash: order.cart_hash
    }
}

async function dataToBilling(orderId, billing){
    return {
        cod_pedido_biling: orderId,
        cod_pedido: orderId,
        firts_name: billing.firts_name,
        last_name: billing.last_name,
        endereco: billing.address_1 + billing.address_2 ? ' - ' + billing.address_2 : '',
        cidade: billing.city,
        estado: billing.state,
        cep: billing.postcode,
        pais: billing.country,
        email: billing.email,
        phone: billing.phone,
        numero: billing.number,
        bairro: billing.neighborhood,
        person_type: billing.persontype,
        cpf: billing.cpf,
        rg: billing.rg,
        cnpj: billing.cnpj,
        ie: billing.ie,
        data_nasc: new Date(billing.birthdate.split('T')[0]),
        genero: billing.sex,
        celular: billing.cellphone
    }
}

async function dataToShipping(orderId, shipping){
    return {
        cod_pedido_shipping: orderId,
        cod_pedido: orderId,
        first_name: shipping.firts_name,
        last_name: shipping.last_name,
        endereco: shipping.address_1 + shipping.address_2 ? ' - ' + shipping.address_2 : '',
        complemento: shipping.address_2,
        cidade: shipping.city,
        estado: shipping.state,
        cep: shipping.postcode,
        pais: shipping.country,
        numero: shipping.number,
        bairro: shipping.neighborhood
    }
}

async function dataToItens(orderId, itens){
    let data = []
    for (let i = 0; i < itens.length; i++) {
        data.push({
            cod_sequencia: itens[i].id,
            cod_produto: itens[i].product_id,
            cod_venda: orderId,
            nome: itens[i].name,
            variation_id: itens[i].variation_id,
            quantidade: itens[i].quantity,
            tax_class: itens[i].tax_class,
            subtotal: itens[i].subtotal != '' ? Number(Number(itens[i].subtotal).toFixed(2)) : 0,
            subtotal_tax: itens[i].subtotal_tax != '' ? Number(Number(itens[i].subtotal_tax).toFixed(2)) : 0,
            sku: itens[i].sku,
            preco: itens[i].price != '' ? Number(Number(itens[i].price).toFixed(2)) : 0,
            parent_name: itens[i].parent_name
        })
    }
    return data
}