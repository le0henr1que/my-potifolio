const UUID = require('../../../patterns/UUID')
const typeRequest = require('../../../patterns/typeRequest')
const sendToDataExtensions = require('../../salesforce/data_extensions/sendToDataExtension')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    let clientReferece = req.query.clientReference
    if(clientReferece){
        let customer = req.body
        if(await validateFields(customer)){
            await initOperation(clientReferece, customer)
        }else{
            console.log('[ERROR] hookCustomer woocommerce operation --> validateFields returns false') //debug
        }
    }else{
        console.log('[ERROR] hookCustomer woocommerce operation --> clientReferece is missing (query on hook)') //debug
    }
    if(isRoute) res.status(200).send()
}

async function validateFields(customer){
    if(customer)
        if(await customer.id && customer.email && customer.username)
            return true

    return false
}

async function initOperation(clientReference, customer){
    let operationId = await UUID()

    let data_Clients = await dataToClient(customer)
                        .catch(err => {console.log('[ERROR] dataToClient --> ' + err)}) //object

    let data_Billing = await dataToBilling(customer)
                        .catch(err => {console.log('[ERROR] dataToBilling --> ' + err)}) //object

    let data_Shipping = await dataToShipping(customer)
                        .catch(err => {console.log('[ERROR] dataToShipping --> ' + err)}) //object

    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Clients], operationId: operationId, dataExtension: 'clients', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Billing], operationId: operationId, dataExtension: 'billing_address', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Shipping], operationId: operationId, dataExtension: 'shipping_address', method: 'put'}))
}

async function dataToClient(customer){
    return {
        contact_id: customer.id,
        wc_contactid: customer.id,
        cpf: customer.billing.cpf,
        nome: customer.first_name,
        sobrenome: customer.last_name,
        email: customer.email,
        usuario: customer.username,
        ddd_telefone: customer.billing.phone != '' ? customer.billing.phone.split(' ')[0].replace('(', '').replace(')', '') : '',
        celular: customer.billing.cellphone != '' ? customer.billing.cellphone : customer.billing.phone,
        dt_nasc: new Date(customer.billing.birthdate.split('T')[0]),
        cadastro_status: customer.role,
        company: customer.billing.company,
        role: customer.role,
        avatar_uel: customer.avatar_url,
        rg: customer.billing.rg,
        genero: customer.billing.sex,
        origem: 'woocommerce',
        data_cadastro: customer.date_created,
        data_alteracao: customer.date_modified
    }
}

async function dataToBilling(customer){
    return {
        cod_end_billing: customer.id,
        cod_cliente: customer.id,
        endereco: customer.billing.address_1,
        numero: customer.billing.number,
        bairro: customer.billing.neighborhood,
        cidade: customer.billing.city,
        estado: customer.billing.state,
        cep: customer.billing.postcode,
        pais: customer.billing.country,
        data_inclusao: customer.date_modified,
        email: customer.email,
        phone: customer.billing.phone ? customer.billing.phone : customer.billing.cellphone
    }
}

async function dataToShipping(customer){
    return {
        cod_end_shipping: customer.id,
        cod_cliente: customer.id,
        endereco: customer.billing.address_1,
        numero: customer.billing.number,
        bairro: customer.billing.neighborhood,
        cidade: customer.billing.city,
        estado: customer.billing.state,
        cep: customer.billing.postcode,
        pais: customer.billing.country,
        data_inclusao: customer.date_modified
    }
}