const UUID = require('../../../patterns/UUID')
const sendToDataExtensions = require('../../salesforce/data_extensions/sendToDataExtension')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    if(clientReferece){
        let product = req.body
        if(await validateFields(product)){
            await initOperation(clientReferece, product)
        }else{
            console.log('[ERROR] hookProducts woocommerce operation --> validateFields returns false') //debug
        }
    }else{
        console.log('[ERROR] hookProducts woocommerce operation --> clientReferece is missing (query on hook)') //debug
    }
    res.status(200).send()
}

async function validateFields(product){
    if(product)
        if(await product.id && product.name && product.sku)
            return true

    return false
}

async function initOperation(clientReference, product){
    let operationId = await UUID()
    
    let data_Product = await dataToProduct(product)
                        .catch(err => {console.log('[ERROR] dataToProduct --> ' + err)}) //object

    let data_Image = await dataToImage(product.id, product.images)
                        .catch(err => {console.log('[ERROR] dataToImage --> ' + err)}) //array

    let [data_Categorie, data_CategorieHasProduct] = await dataToCategorie(product.id, product.categories)
                        .catch(err => {console.log('[ERROR] dataToCategorie --> ' + err)}) //array //array

    let data_AttDefault = await dataToAttDefault(product.id, product.default_attributes)
                        .catch(err => {console.log('[ERROR] dataToAttDefault --> ' + err)}) //array

    let data_Attributes = await dataToAttributes(product.id, product.attributes)
                        .catch(err => {console.log('[ERROR] dataToAttributes --> ' + err)}) //array

    let data_Related = await dataToRelated(product.id, product.related_ids)
                        .catch(err => {console.log('[ERROR] dataToRelated --> ' + err)}) //array

    console.log(await sendToDataExtensions({clientReference: clientReference, records: [data_Product], operationId: operationId, dataExtension: 'product', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_Image, operationId: operationId, dataExtension: 'product_images', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_Categorie, operationId: operationId, dataExtension: 'categories', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_CategorieHasProduct, operationId: operationId, dataExtension: 'categories_has_product', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_AttDefault, operationId: operationId, dataExtension: 'attributes_default', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_Attributes, operationId: operationId, dataExtension: 'attributes', method: 'put'}))
    console.log(await sendToDataExtensions({clientReference: clientReference, records: data_Related, operationId: operationId, dataExtension: 'related', method: 'put'}))
}

async function dataToProduct(product){
    return {
        cod_produto: product.id,
        slug: product.slug,
        name: product.name,
        permalink: product.permalink,
        tipo: product.type,
        status: product.status,
        featured: product.featured,
        catalog_visible: product.catalog_visibitily,
        descricao: product.description,
        descricao_resumo: product.short_description,
        sku: product.sku,
        valor: product.price != '' ? Number(Number(product.price).toFixed(2)) : 0,
        valor_regular: product.regular_price != '' ? Number(Number(product.regular_price).toFixed(2)) : 0,
        valor_venda: product.sale_price != '' ? Number(Number(product.sale_price).toFixed(2)) : 0,
        data_valor_venda: product.date_on_sale_from,
        data_fim_valor_venda: product.date_on_sale_to,
        price_html: product.price_html,
        avenda: product.on_sale,
        compravel: product.purchasable,
        total_vendas: product.total_sales,
        virtual: product.virtual,
        downloadable: product.downloadable,
        download_limit: product.download_limit,
        download_expired: product.expiry,
        external_url: product.external_url,
        button_text: product.button_text,
        tax_status: product.tax_status,
        tax_class: product.tax_class,
        menage_stock: product.menage_stock,
        stock_quantity: product.stock_quantity,
        stock_status: product.stock_status,
        backorders: product.backorders,
        backorders_allowed: product.backorders_allowed,
        sold_individually: product.sold_individually,
        weight: product.weight,
        shipping_required: product.shipping_required,
        shipping_taxable: product.shipping_taxable,
        shipping_class: product.shipping_class,
        shipping_class_id: product.shipping_class_id,
        reviews_allowed: product.reviews_allowed,
        average_rating: product.average_rating,
        rating_count: product.rating_count,
        parent_id: product.parent_id,
        purchase_note: product.purchase_note,
        menu_order: product.menu_order
    }
}

async function dataToImage(productId, images){
    let data = []
    for (let i = 0; i < images.length; i++) {
        data.push({
            cod_produto_imagem: images[i].id,
            cod_produto: productId,
            data_criacao: images[i].date_created,
            data_alteracao: images[i].date_modified,
            src: images[i].src,
            nome: images[i].name,
            alt: images[i].alt
        })   
    }
    return data
}

async function dataToCategorie(productId, categories){
    let categorie = []
    let categorie_has_product = []
    for (let i = 0; i < categories.length; i++) {
        categorie.push({
            cod_categoria: categories[i].id,
            name: categories[i].name,
            slug: categories[i].slug
        })
        categorie_has_product.push({
            cod_produto: productId,
            cod_categoria: categories[i].id
        })
    }
    return [categorie, categorie_has_product]
}

async function dataToAttDefault(productId, _default){
    let data = []
    for (let i = 0; i < _default.length; i++) {
        data.push({
            cod_produto_att_default: _default[i].id,
            cod_produto: productId,
            name: _default[i].name,
            option: _default[i].option
        })   
    }
    return data
}

async function dataToAttributes(productId, attributes){
    let data = []
    for (let i = 0; i < attributes.length; i++) {
        data.push({
            cod_produto_atributos: attributes[i].id,
            cod_produto: productId,
            nome: attributes[i].name,
            position: attributes[i].position,
            visible: attributes[i].visible,
            variation: attributes[i].variation
        })   
    }
    return data
}

async function dataToRelated(productId, related){
    let data = []
    for (let i = 0; i < related.length; i++) {
        data.push({
            cod_produto: productId,
            cod_produto_rel: related[i],
            Tipo: 'R'
        })   
    }
    return data
}