const axios = require('axios')
const { getWooAccess } = require('../database/querys/wooQuery')
const hookCoupons = require('../callback/hookCoupons')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    let access = await getWooAccess('caabus',  clientReferece, 'access endpoints')
    await runList(access, req, res, 50, 1)
}

async function runList(access, req, res, limit, iteration){
    return new Promise(async resolve => {
        let coupons = await getData(access, limit, iteration)
        if(coupons){
            if(coupons.length > 0){
                for (let i = 0; i < coupons.length; i++) {
                    console.log(`[INFO] iteration ${iteration} coupons length ${coupons.length} loop --> ${i}`) //debug
                    req.body = coupons[i]
                    await hookCoupons(req, res)
                }
                // resolve(access, req, res, limit, iteration+1)
                resolve()
            }else{
                resolve()
            }
        }
    })
}

async function getData({access, endpoints}, limit, iteration){
    return new Promise(resolve => {
        let url = endpoints.coupon.replace('{couponId}', '') + '?per_page=' + limit + '&page=' + iteration
        axios.get(url, {
            auth: {
                username: access.customer_key,
                password: access.customer_secret
            }
        }).then(response => {
            resolve(response.data)
        }, err => {
            console.log(err.response.data)
            resolve()
        })
    })
}