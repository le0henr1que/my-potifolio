const axios = require('axios')
const { getWooAccess } = require('../database/querys/wooQuery')
const hookOrders = require('../callback/hookOrders')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    let access = await getWooAccess('caabus',  clientReferece, 'access endpoints')
    await runList(access, req, res, 50, 2)
}

async function runList(access, req, res, limit, iteration){
    return new Promise(async resolve => {
        let orders = await getData(access, limit, iteration)
        if(orders){
            if(orders.length > 0){
                for (let i = 0; i < orders.length; i++) {
                    console.log(`[INFO] iteration ${iteration} orders length ${orders.length} loop --> ${i}`) //debug
                    req.body = orders[i]
                    await hookOrders(req, res)
                }
                resolve(await runList(access, req, res, limit, iteration+1).catch(err => {}))
            }else{
                resolve()
            }
        }
    })
}

async function getData({access, endpoints}, limit, iteration){
    return new Promise(resolve => {
        let url = endpoints.order.replace('{orderId}', '') + '?per_page=' + limit + '&page=' + iteration
        axios.get(url, {
            auth: {
                username: access.customer_key,
                password: access.customer_secret
            }
        }).then(response => {
            resolve(response.data)
        }, err => {
            console.log(err.response.data)
            resolve()
        })
    })
}