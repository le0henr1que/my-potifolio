const axios = require('axios')
const { getWooAccess } = require('../database/querys/wooQuery')
const hookProduct = require('../callback/hookProducts')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    let access = await getWooAccess('caabus',  clientReferece, 'access endpoints')
    await runList(access, req, res, 50, 1).catch(err => {})
}

async function runList(access, req, res, limit, iteration){
    return new Promise(async resolve => {
        let products = await getData(access, limit, iteration).catch(err => {})
        if(products){
            if(products.length > 0){
                for (let i = 0; i < products.length; i++) {
                    console.log(`[INFO] iteration ${iteration} products length ${products.length} loop --> ${i}`) //debug
                    req.body = products[i]
                    await hookProduct(req, res)
                }
                resolve(await runList(access, req, res, limit, iteration+1).catch(err => {}))
            }else{
                resolve()
            }
        }
    })
}

async function getData({access, endpoints}, limit, iteration){
    return new Promise(resolve => {
        let url = endpoints.product.replace('{productId}', '') + '?per_page=' + limit + '&page=' + iteration
        axios.get(url, {
            auth: {
                username: access.customer_key,
                password: access.customer_secret
            }
        }).then(response => {
            resolve(response.data)
        }, err => {
            console.log(err.response.data)
            resolve()
        })
    })
}