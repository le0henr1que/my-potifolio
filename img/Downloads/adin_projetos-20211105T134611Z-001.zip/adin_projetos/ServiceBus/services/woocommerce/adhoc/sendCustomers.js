const axios = require('axios')
const { getWooAccess } = require('../database/querys/wooQuery')
const hookCustomers = require('../callback/hookCustomers')

module.exports = async (req, res) => {
    let clientReferece = req.query.clientReference
    let access = await getWooAccess('caabus',  clientReferece, 'access endpoints')
    await runList(access, req, res, 50, 29).catch(err => {})
}

async function runList(access, req, res, limit, iteration){
    return new Promise(async resolve => {
        let customers = await getData(access, limit, iteration).catch(err => {})
        if(customers){
            if(customers.length > 0){
                for (let i = 0; i < customers.length; i++) {
                    console.log(`[INFO] iteration ${iteration} customers length ${customers.length} loop --> ${i}`) //debug
                    req.body = customers[i]
                    await hookCustomers(req, res)
                }
                resolve(await runList(access, req, res, limit, iteration+1).catch(err => {}))
            }else{
                resolve()
            }
        }
    })
}

async function getData({access, endpoints}, limit, iteration){
    return new Promise(resolve => {
        let url = endpoints.customer.replace('{customerId}', '') + '?per_page=' + limit + '&page=' + iteration
        axios.get(url, {
            auth: {
                username: access.customer_key,
                password: access.customer_secret
            }
        }).then(response => {
            resolve(response.data)
        }, err => {
            console.log(err.response.data)
            resolve()
        })
    })
}