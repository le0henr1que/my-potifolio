const schedule = require('node-schedule')
const { getSalesforceAccess, saveSalesforceRecord } = require('../database/querys/salesforceQuery')
const getToken = require('../token/getToken')

module.exports = {
    scheduleRefreshTokens: async () => {
        await initRefreshTokens() //refresh at last once after boot
        schedule.scheduleJob('0 */1 * * * *',  async () => {
            await initRefreshTokens()
        })
    }
}

async function initRefreshTokens(){
    let clients = require('../config/clients.json')
    for (let i = 0; i < clients.length; i++) {
        let client = await getSalesforceAccess(clients[i].database, clients[i].name)
        if(client)
        if(client.access){
            if(client.access.access_token){
                if(await compareIfExpires(client.access.expires_in))
                    await updateToken(client)
            }else{
                await updateToken(client)
            }
        }
    }
}

async function updateToken(client){
    getToken(client.access).then(async () => {
        client.markModified('access')
        await saveSalesforceRecord(client)
    }).catch(err => {
        console.log('[ERROR] in update token --> ' + err) //debug
    })
}

async function compareIfExpires(expires){
    let now = new Date()
    expires = new Date(expires)
    return now.getTime() >= expires.getTime()
}