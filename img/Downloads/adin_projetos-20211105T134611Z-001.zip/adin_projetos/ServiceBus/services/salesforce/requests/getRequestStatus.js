const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { getSalesforceAccess } = require('../database/querys/salesforceQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let access = await getSalesforceAccess('caabus', payload.clientReference, 'access requests')
        if(access){
            let result = await initProcess(payload.requestId, access).catch(err => {
                console.log('[ERRO] initProcess to requests salesforce --> ' + JSON.stringify(err, null, 2)) //debug
            })
            if(result){
                if(isRoute) res.status(200).send({request: result})
                return result
            }else{
                if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }    
}

async function validateFields(payload){
    if(await payload.clientReference &&  payload.operationId && payload.requestId)
        if(await payload.clientReference != '' && payload.operationId != '' && payload.requestId != '')
            if(await payload.records.length > 0)
                return true
    
    return false
}

async function initProcess(requestId, confs){
    return new Promise(async resolve => {
        let dataToReturn = {}
        dataToReturn = await sendData(requestId, confs).catch(err => {
            console.log('[ERRO] sendData to requests salesforce --> ' + err)
            dataToReturn = err
        })
        resolve(dataToReturn)
    })
}

async function sendData(requestId, {access, requests}){
    return new Promise((resolve, reject) => {
        let url = access.rest_instance_url+requests.base.replace('{requestId}', requestId)
        axios.get(url, {
            headers:{
                'Authorization': `${access.token_type} ${access.access_token}`
            }
        }).then(async r => {
            resolve(r.data)
        }, error => {
            reject(error.response.data)
        })
    })
}