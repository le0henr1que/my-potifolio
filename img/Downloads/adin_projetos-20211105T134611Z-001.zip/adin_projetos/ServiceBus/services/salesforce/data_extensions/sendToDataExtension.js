const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { getSalesforceAccess } = require('../database/querys/salesforceQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let access = await getSalesforceAccess('caabus', payload.clientReference, 'access data_extensions')
        if(access){
            if(access.data_extensions[payload.dataExtension]){
                let result = await initProcess(payload, access).catch(err => {
                    console.log('[ERRO] initProcess to data_extensions salesforce --> ' + JSON.stringify(err, null, 2)) //debug
                })
                if(result){
                    if(isRoute) res.status(200).send({request: result})
                    return result
                }else{
                    if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
                }
            }else{
                if(isRoute) res.status(403).send({error: true, message: 'data extension not allowed'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }    
}

async function validateFields(payload){
    if(await payload.clientReference && payload.records && payload.operationId && payload.dataExtension && payload.method)
        if(await payload.clientReference != '' && Array.isArray(payload.records) != '' && payload.operationId != '' && payload.dataExtension != '' && payload.method != '')
            if(await payload.records.length > 0)
                return true
    
    return false
}

async function initProcess({records, dataExtension, method}, confs){
    return new Promise(async resolve => {
        let dataToReturn = {}
        dataToReturn = await sendData(records, dataExtension, method, confs).catch(err => {
            console.log('[ERRO] sendData to data_extensions salesforce --> ' + JSON.stringify(err, null, 2))
            dataToReturn = err
        })
        resolve(dataToReturn)
    })
}

async function sendData(records, dataExtension, method, {access, data_extensions}){
    return new Promise((resolve, reject) => {
        let data = {
            items: records
        }
        axios[method](access.rest_instance_url+data_extensions[dataExtension], data, {
            headers:{
                'Content-Type': 'application/json',
                'Authorization': `${access.token_type} ${access.access_token}`
            }
        }).then(async r => {
            resolve(r.data)
        }, error => {
            reject(error)
        })
    })
}