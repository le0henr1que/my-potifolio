const { createModel } = require('../schemas/salesforceSchema')

exports.getSalesforceAccess = async (clientName, clientReference, select) => {
    let model = await createModel(clientName)
    return await model.findOne({$or: [{name: clientReference}, {_idClient: clientReference}]}).select(select).exec()
}

exports.saveSalesforceRecord = async payload => {
    return new Promise(resolve => {
        payload.save(err => {
            if(err) console.log('[ERROR] save sales force record --> ' + err) //debug

            resolve()
        })
    })
}