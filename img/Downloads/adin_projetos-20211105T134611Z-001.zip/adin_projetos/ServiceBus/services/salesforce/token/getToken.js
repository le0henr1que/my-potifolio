const axios = require('axios')

module.exports = async (access, scope) => {
    return new Promise((resolve, reject) => {
        let data = {
            grant_type: "client_credentials",
            client_id: access.client_id,
            client_secret: access.client_secret,
            scope: scope,
            account_id: ""
            }
        axios.post(access.url_login, data, {headers: {'Content-Type': 'application/json'}})
        .then(async r => {
            access.access_token = r.data.access_token
            access.token_type = r.data.token_type
            access.expires_in = await calculateExpires(r.data.expires_in)
            access.scope = r.data.scope
            access.rest_instance_url = r.data.rest_instance_url
            resolve()
        }, err => {
            reject(`[ERROR] in getToken for client ${access.username} --> ${err}`)
        })
    })
}

async function calculateExpires(time){
    let date = new Date()
    date.setSeconds(date.getSeconds() + time)
    return date
}