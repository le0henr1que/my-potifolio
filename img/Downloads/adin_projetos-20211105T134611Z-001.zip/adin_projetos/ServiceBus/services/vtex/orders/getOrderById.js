const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { getVtexAccess } = require('../database/querys/vtexQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let confs = await getVtexAccess('caabus', payload.clientReference, 'access orders')
        if(confs){
            let order = await getData(confs, payload.orderId).catch(err => {})
            if(order){
                if(isRoute) res.status(order[0]).send(order[1]) // to route
                if(order[0] === 200) return order[1] // to function call
            }else{
                if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }
}

async function validateFields(payload){
    if(await payload.clientReference && payload.orderId)
        if(await payload.clientReference != '' && payload.orderId != '')
            return true

    return false
}

async function getData({access, orders}, orderId){
    return new Promise((resolve, reject) => {
        let url = orders.base.replace('{accountName}', access.accountName).replace('{orderId}', orderId)
        axios.get(url, {
            headers:{
                'Content-Type': 'application/json',
                'X-VTEX-API-AppKey': access.AppKey,
                'X-VTEX-API-AppToken': access.AppToken
            }
        }).then(async r => {
            resolve([200, r.data])
        }, async error => {
            if(await error.response.data.error)
                if(await error.response.data.error.message == 'Order Not Found')
                    resolve([204], {message: 'order not found'})

            console.log(`[ERROR] in getData orderId vtex --> ${JSON.stringify(error.response.data, null, 2)}`)
            resolve([500], {error: true, message: "vtex response is not maped, please contact the devs"})
        })
    })
}