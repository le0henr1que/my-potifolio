const axios = require('axios')
const typeRequest = require('../../../patterns/typeRequest')
const { getVtexAccess } = require('../database/querys/vtexQuery')

module.exports = async (req, res) => {
    let [payload, isRoute] = await typeRequest(req, res)
    if(await validateFields(payload)){
        let confs = await getVtexAccess('caabus', payload.clientReference, 'access users')
        if(confs){
            let user = await getData(confs, payload.userProfileId).catch(err => {})
            if(user){
                if(isRoute) res.status(user[0]).send(user[1]) // to route
                if(user[0] === 200) return user[1] // to function call
            }else{
                if(isRoute) res.status(500).send({error: true, message: 'erro in process records, please contact the devs'})
            }
        }else{
            if(isRoute) res.status(403).send({error: true, message: 'client not allowed'})
        }
    }else{
        if(isRoute) res.status(400).send({error: true, message: 'missing fields'})
    }
}

async function validateFields(payload){
    if(await payload.clientReference && payload.userProfileId)
        if(await payload.clientReference != '' && payload.userProfileId != '')
            return true

    return false
}

async function getData({access, users}, userProfileId){
    return new Promise((resolve, reject) => {
        let url = users.base.replace('{accountName}', access.accountName).replace('{userProfileId}', userProfileId)
        axios.get(url, {
            headers:{
                'Content-Type': 'application/json',
                'X-VTEX-API-AppKey': access.AppKey,
                'X-VTEX-API-AppToken': access.AppToken
            }
        }).then(async r => {
            resolve([200, r.data[0].email])
        }, async error => {
            console.log(`[ERROR] in getData userProfileId vtex --> ${JSON.stringify(error.response.data, null, 2)}`)
            resolve([500], {error: true, message: "vtex response is not maped, please contact the devs"})
        })
    })
}