const { createModel } = require('../schemas/vtexSchema')

exports.getVtexAccess = async (clientName, clientReference, select) => {
    let model = await createModel(clientName)
    return await model.findOne({$or: [{name: clientReference}, {_idClient: clientReference}]}).select(select).exec()
}