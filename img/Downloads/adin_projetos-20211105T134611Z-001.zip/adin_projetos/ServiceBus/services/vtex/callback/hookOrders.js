const UUID = require('../../../patterns/UUID')
const getOrderById = require('../orders/getOrderById')
const getUserById = require('../users/getUserById')
const sendToContactList = require('../../responsys/contact_list/sendToContactList')
const sendToSupplemental = require('../../responsys/supplemental/sendToSupplemental')

module.exports = async (req, res) => {
    let clientReferece = req.headers.key
    if(clientReferece){
        let order = await getOrderById({
            clientReference: clientReferece,
            orderId: req.body.OrderId
        })
        if(order){
            let userProfileId = order.clientProfileData.userProfileId
            let email = await getUserById({
                clientReference: clientReferece,
                userProfileId: userProfileId
            })
            let uuid = await UUID()
            await sendToResponsysContactList(email, order, clientReferece, uuid)
            await sendToResponsysSuplemental(email, order, clientReferece, uuid)
        }else{
            console.log('[INFO] hookOrders vtex operation --> no order return')
        }
    }else{
        console.log('[ERROR] hookOrders vtex operation --> clientReferece is missing (key header on hook)')
    }

    res.status(200).send()
}

async function sendToResponsysContactList(email, order, clientReferece, uuid){
    let data = {
        clientReference: clientReferece,
        operationId: uuid,
        matchColumn: "EMAIL_ADDRESS_",
        records: [{
            EMAIL_ADDRESS_: email,
            FIRST_NAME: order.clientProfileData.firstName,
            LAST_NAME: order.clientProfileData.lastName,
            MOBILE_NUMBER_: order.clientProfileData.phone
        }]
    }
    console.log(JSON.stringify(await sendToContactList(data), null, 2)) //debug
    // await sendToContactList(data)
}

async function sendToResponsysSuplemental(email, order, clientReferece, uuid){
    let records = []
    for (let i = 0; i < order.items.length; i++) {
        let item = await order.items[i]
        try{
            records.push({
                ORDER_: order.orderId,
                CREATION_DATE: new Date(order.creationDate),
                // CLIENT_NAME: order.clientProfileData.firstName,
                // CLIENT_LAST_NAME: order.clientProfileData.lastName,
                CLIENT_DOCUMENT: order.clientProfileData.document,
                EMAIL: email,
                // PHONE_NUMBER: order.clientProfileData.phone,
                UF: order.shippingData.address.state,
                CITY: order.shippingData.address.city,
                STREET: order.shippingData.address.street,
                NUMBER_: order.shippingData.address.number,
                COMPLEMENT: order.shippingData.address.complement,
                NEIGHBORHOOD: order.shippingData.address.neighborhood,
                POSTAL_CODE: order.shippingData.address.postalCode,
                SLA_TYPE: order.shippingData.logisticsInfo[i].selectedSla,
                ESTIMATE_DELIVERY_DATE: new Date(order.shippingData.logisticsInfo[i].shippingEstimateDate),
                DELIVERY_DEADLINE: order.shippingData.logisticsInfo[i].shippingEstimate,
                STATUS: order.statusDescription,
                COUPON: order.marketingData.coupon,
                PAYMENT_SYSTEM_NAME: order.paymentData.transactions[0].payments[0].paymentSystemName,
                ISNTALLMENTS: order.paymentData.transactions[0].payments[0].installments.toString(),
                QUANTITY_SKU: item.quantity.toString(),
                REFERENCE_CODE: item.refId,
                SKU_NAME: item.name,
                SKU_VALUE: await convertValueNumber(item.price),
                SKU_SELLING_PRICE: await convertValueNumber(item.sellingPrice),
                SKU_TOTAL_PRICE: await convertValueNumber(item.sellingPrice * item.quantity),
                SHIPPING_LIST_PRICE: await convertValueNumber(order.shippingData.logisticsInfo[i].listPrice),
                SHIPPING_VALUE: await convertValueNumber(order.shippingData.logisticsInfo[i].sellingPrice),
                TOTAL_VALUE: await convertValueNumber(order.value),
                TRACKING_NUMBER: order.packageAttachment.packages[0] ? order.packageAttachment.packages[0].trackingNumber : 'N/A',
                INVOICE_NUMBERS: order.packageAttachment.packages[0] ? order.packageAttachment.packages[0].invoiceNumber : 'N/A'
            })
        }catch(e){}
    }
    let data = {
        clientReference: clientReferece,
        operationId: uuid,
        operationName: 'vtex_orders',
        records: records
    }
    console.log(JSON.stringify(await sendToSupplemental(data), null, 2))
    // await sendToSupplemental(data)
}

async function convertValueNumber(number){
    if(number > 0 && number != null & number != undefined){
        let numberArray = Array.from(number.toString())
        numberArray.splice(numberArray.length-2, 0, '.')
        numberArray = numberArray.join('')
        return numberArray
    }else{
        return '0'
    }
}