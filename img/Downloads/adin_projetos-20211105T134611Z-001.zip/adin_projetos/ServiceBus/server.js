const app = require('./config/express')()
const port = app.get('port')
const initService = require('./boot/initService')

async function boot(){
    await initService(app)
    app.listen(port, async () => {
        console.log(`[SUCCESS] ServiceBus running at ${port}`)
    })
}

boot()