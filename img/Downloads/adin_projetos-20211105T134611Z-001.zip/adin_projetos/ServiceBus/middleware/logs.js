module.exports =  {

    logger: function (req, res, next) {
        console.log('LOGGED');
        console.log(`${req.method}:${req.path}`);
        console.log(req.body);
        // console.log(req.headers);
        next();
    }    
    
}