function buscar(){

    let dest = document.getElementById('destinatario').value
    let mensagem = document.getElementById('mensagem').value
    //alert(dest)
    //alert(mensagem)
   

    //username = "denis.silva@adin.com.br"
    //password = "EiAlerta321@2021"
    //url_login = "https://api.eialerta.com.br/bin/token"


    //const crypto = require('crypto');

    //'email': 'denis.silva@adin.com.br',
    //'password': 'EiAlerta321@2021'


}


const data = JSON.stringify(false);

const xhr = new XMLHttpRequest();
xhr.withCredentials = true;

xhr.addEventListener("readystatechange", function () {
  if (this.readyState === this.DONE) {
    console.log(this.responseText);
  }
});

xhr.open("GET", "https://api.eialerta.com.br/bin/token");
xhr.setRequestHeader("Authorization", "Basic ZGVuaXMuc2lsdmFAYWRpbi5jb20uYnI6RWlBbGVydGEzMjFAMjAyMQ==");

xhr.send(data);
















 
  



