let addinName = 'Integração WhatsApp'//mudar nome
let addinVersion = '1.0'//confirmar versão
let iconClass = 'bi bi-collection'//confirmar collection

ORACLE_SERVICE_CLOUD.extension_loader.load(addinName,addinVersion).then(function(arquivos){
    arquivos.registerUserInterfaceExtension(function (userInterfaceContext){
        userInterfaceContext.getLeftSidePaneContext().then(function (leftSidePaneContext){
            leftSidePaneContext.getSidePane('id').then(function(leftPanelMenu){
                /*let icon = leftPanelMenu.createIcon('font awesome')
				icon.setIconClass(iconClass)
				leftPanelMenu.addIcon(icon)*/
                leftPanelMenu.setWidth(400)
                leftPanelMenu.setResizeEnabled(true)
                leftPanelMenu.render()
            })
        })
    })
})

