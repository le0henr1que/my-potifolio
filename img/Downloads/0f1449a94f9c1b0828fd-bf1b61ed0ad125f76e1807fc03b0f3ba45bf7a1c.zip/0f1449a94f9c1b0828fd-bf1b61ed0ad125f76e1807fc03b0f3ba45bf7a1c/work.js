//Work Array 

var works = ["img/online.jpg","img/mobile.jpg","img/card.jpg","img/pos.jpg",
"img/online.jpg","img/mobile.jpg","img/card.jpg","img/pos.jpg"];
